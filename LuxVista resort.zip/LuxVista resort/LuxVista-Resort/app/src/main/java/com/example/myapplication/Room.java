package com.example.myapplication;
public class Room {
    public String Price;
    public String details;
    public String image;
    public String name;
    // Default constructor and getters/setters
}

