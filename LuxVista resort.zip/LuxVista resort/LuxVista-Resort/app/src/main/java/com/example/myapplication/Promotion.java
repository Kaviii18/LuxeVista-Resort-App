package com.example.myapplication;

public class Promotion {
    public String name;
}
