package com.example.myapplication;

public class User {
    public String email;
    public String password;
    public String name;

    // Default constructor and getters/setters
}
