package com.example.myapplication;

// Create a data class to store payment information
public class ServiceData {
    public String name, Price, details,image;

    public ServiceData(String name, String Price, String details, String image) {
        this.name = name;
        this.Price = Price;
        this.details = details;
        this.image = image;

    }
}
