package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.myapplication.R;

public class MainActivity extends AppCompatActivity {

    private TextView titleText, hotelName, descriptionText, priceText;
    private RatingBar hotelRating;
    private Button bookNowButton;
    private ImageView image1, image2;
    private CardView hotelCard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        titleText = findViewById(R.id.titleText);
        hotelName = findViewById(R.id.hotelName);
        descriptionText = findViewById(R.id.descriptionText);
        priceText = findViewById(R.id.priceText);
        hotelRating = findViewById(R.id.hotelRating);
        bookNowButton = findViewById(R.id.bookNowButton);
        image1 = findViewById(R.id.Image1);
        image2 = findViewById(R.id.Image2);
        hotelCard = findViewById(R.id.hotelCard);

        // Set the initial data for views
        titleText.setText("Find Your Dream Hotel");
        hotelName.setText("LuxeVista Resort");
        descriptionText.setText("Experience unparalleled luxury at LuxeVista Resort. Our exquisite rooms, world-class dining, and pampering spa treatments will transport you to a world of pure bliss.");
        priceText.setText("Starting from $199/night");
        hotelRating.setRating(4.5f);

        // Initially, set the second image (image2) as hidden
        image2.setVisibility(View.GONE);

        // Button click listener for "Explore Now"
        bookNowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Open SecondActivity when button is clicked
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                startActivity(intent);
            }
        });
    }
}











